const gretter = (myArray, counter) => {
    for(let name of myArray){
        const greeting = `Hello ${name}`
        console.log(greeting)
    }
}

gretter(['Randy Savage', 'Ric Flair', 'Hulk Hogan'], 3)


function capitalize(string){
    return string[0].toUpperCase() + string.slice(1).toLowerCase();
}

console.log(capitalize('fooBar'))

function capitalizeWords(arr) {
    return arr.map(element => {
      return element.charAt(0).toUpperCase() + element.slice(1).toLowerCase();
    });
}

console.log(capitalizeWords(['red', 'green', 'blue']))

values = [1, 60, 34, 30, 20, 5]

var filtered = values.filter(function(x) {
    return x < 20;
})

console.log(filtered)

var array = [1, 2, 3, 4],
    sum = 0,
    product = 1,
    i;

for (i = 0; i < array.length; i += 1)
{
    sum += array[i];
    product *= array[i];
}
console.log(sum);
console.log(product);

class Vehicle {
    constructor(brand, year, price) {
        this.carname = brand;
        this.year = year;
        this.price = price;
    }
}

class Car extends Vehicle {
    constructor (brand, year){
        super(brand);
        this.year = year;
    }
    details(){
        console.log('Model: ' + this.carname + ' engine ' + this.year);
    }
}

class Sedan extends Vehicle {
    constructor (brand, year, price){
        super(brand);
        this.price = price;
    }
    info(){
        console.log(this.carname + ' has a balance of $' + this.price);
    }
}

const car2 = new Car('Pontiac Firebird', 1976);
const sedan = new Sedan('Volvo SD', 2018, 30000)
car2.details();
sedan.info();